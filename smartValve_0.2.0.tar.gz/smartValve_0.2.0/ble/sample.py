###############################
# BluezHandler example
# 
# David, Shin @ Highmaru, Inc
###############################
from BluezHandler import Characteristic, Descriptor,BluezHandler
from gi.repository import GLib
import json, os.path

# import BluezHandler

FIFO_BLE_RD = '/tmp/FIFO_SIO_BLE'
FIFO_BLE_WR = '/tmp/FIFO_BLE_SIO'

SMARTVALVE_SERVICE_UUID =   '0000FFE0-0000-1000-8000-00805F9B34FB'
SMARTVALVE_CONTROL_UUID =   '0000FFE1-0000-1000-8000-00805F9B34FB'
SMARTVALVE_SENSOR_UUID =    '0000FFE2-0000-1000-8000-00805F9B34FB'
SMARTVALVE_ENV_UUID =       '0000FFE3-0000-1000-8000-00805F9B34FB'
LOCAL_NAME =                   'SmartValve'

mainloop = None

fifow: int;
fifor: int;

class EnvCharacteristic(Characteristic):
    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, SMARTVALVE_ENV_UUID,
                                ['read','write'], service)
        self.value=[]
        self.add_descriptor(EnvDescriptor(bus,0,self))

    def WriteValue(self, value, options):
        # print('remote: {}'.format(bytearray(value).decode()))
        print('W] '+repr(value))
        fifo_wr.write(str(value))

        try:
            jstr = ''.join([str(ch) for ch in value])
            print('W]: %s' % jstr)
            jobj = json.loads(jstr)
            print('a: %s' % jobj['a'])
        except:
            print("W]: %s" % [int(v) for v in value])    
        self.value = value

    def ReadValue(self, options):
        rd = fifo_rd.read()
        return rd

        #print('R] '+repr(self.value))
        #return self.value
        # print('R] {}'.format(options))
        # return [
        #         dbus.Byte('T'), dbus.Byte('e'), dbus.Byte('s'), dbus.Byte('t')
        # ]

class EnvDescriptor(Descriptor):
    """
    Dummy test descriptor. Returns a static value.

    """
    TEST_DESC_UUID = '12345678-1234-5678-1234-56789abcdef2'

    def __init__(self, bus, index, characteristic):
        Descriptor.__init__(
                self, bus, index,
                self.TEST_DESC_UUID,
                ['read', 'write'],
                characteristic)

    def ReadValue(self, options):
        print('RD]')
        return [
                dbus.Byte('T'), dbus.Byte('e'), dbus.Byte('s'), dbus.Byte('t')
        ]
    def WriteValue(self, value, options):
        print('WD]',value)

def main():

    mainloop = GLib.MainLoop()

    fifoww = open(FIFO_BLE_WR, "w");
    fiforr = open(FIFO_BLE_RD, "r");

    man = BluezHandler()
    service = man.setApplication(LOCAL_NAME,SMARTVALVE_SERVICE_UUID)
    service.add_characteristic(EnvCharacteristic(man.bus,3,service))
    man.start()
    try:
        mainloop.run()
    except KeyboardInterrupt:
        man.Release()

if __name__ == '__main__':
    main()
