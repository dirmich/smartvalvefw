cd ..
wget https://raw.githubusercontent.com/dirmich/smartvalvefw/main/smartValve$1.tar.gz
tar -xf smartValve$1.tar.gz
sudo rm -f smartValve
sudo ln -s smartValve$1 smartValve
sudo reboot now
