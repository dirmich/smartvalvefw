python CameraUpload.py https://remote.komoto.co.kr:3000/api/image/upload 660640cb3027cf3c5f32c10a 10
