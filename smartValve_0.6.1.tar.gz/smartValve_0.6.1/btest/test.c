/*********************************************************************
    sw_valve.c  (Rev 0.90)

    SwitchBox Websocket Main

    Copyright(C)

    Programmed by  Stellar Respree
----------------------------------------------------------------------
22.0905 : Update
23.0824 : Initial
23.1122 : Beta for SmartValve
*********************************************************************/

#include <global.h>
#include <fcntl.h>
#include "sw_type.h"
#include "sio.h"


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
#define WFIFO   "/tmp/FIFO_BLE_SIO"
#define RFIFO   "/tmp/FIFO_SIO_BLE"


// -------------------------------------------------------------------
//  Global Variable
// -------------------------------------------------------------------
static  SWBOX*  pMM;


// -------------------------------------------------------------------
//  Main Function : Websocket
// -------------------------------------------------------------------
int     main(int argc, char* argv[])
{
    int     iCase = 1;

    int     hWFIFO;
    int     hRFIFO;
    char    sSend[1024];
    char    sRecv[1024];
    int     iRecv;

     printf("Processing Case %d\n", iCase);

    if ( argc > 1) {
        iCase = atoi( argv[1] );
    }

    switch (iCase) {
    case 1:
            strcpy (sSend, "{'WIFI':{'ssid':'zzzzz','passwd':'qqqqq','key_mgmt':'WPA-PSK'}}");

            break;
    case 2:
            strcpy (sSend, "[RE]");
            break;
    case 3:
            strcpy (sSend, "[RE]");
            break;
    case 4:
            strcpy (sSend, "[RC]");
            break;
    }


    for ( int i = 0 ; i < strlen(sSend) ; i++ ) {
        if ( sSend[i] == '\'' ) sSend[i] = '"';
    }


    hWFIFO = open(WFIFO, O_WRONLY);
    write(hWFIFO, sSend, strlen(sSend));
    close(hWFIFO);

    sleep(3);

    hRFIFO = open(RFIFO, O_RDONLY);
    memset(sRecv, 0, 1024);
    iRecv = read(hRFIFO, sRecv, 1024);
    close(hRFIFO);
    sRecv[iRecv] = 0;

    printf("FIFO Send : %s\n", sSend);
    printf("FIFO Recv : %s\n", sRecv);

    return(TRUE);
}

