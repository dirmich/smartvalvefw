/*********************************************************************
    sw_valve.c  (Rev 0.90)

    SwitchBox Websocket Main

    Copyright(C)

    Programmed by  Stellar Respree
----------------------------------------------------------------------
22.0905 : Update
23.0824 : Initial
23.1122 : Beta for SmartValve
*********************************************************************/

#define CONTROLLER_I0       "e4:5f:01:3b:7d:23"
#define CONTROLLER_ID       "e4:5f:01:3b:7d:25"
#define USE_NATS_SERVER
#define USE_MODBUS

#include <global.h>
#include "local.h"
#include "sw_type.h"
#include "hal.h"
#include "nio.h"
#include "sio.h"
#include "modbus.h"
#include "timer.h"
#include "fifo.h"
#ifdef USE_NATS_SERVER
#include "nats.h"
#endif
#include "payload.h"


// -------------------------------------------------------------------
//  Type Definition
// -------------------------------------------------------------------
#define USLEEP_DELAY    (1 * 1000 * 1000)
#define SECOND_PER_DAY  86400
#define LOOP_DELAY      4

#define CONFIG_FILE     "config.txt"
#define DEFAULT_FILE    "default.txt"


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
int     ParseArg(int argc, char* argv[]);
void    WriteQuitFile();
void*   BleWorker(void* pParam);
void*   ModbusWorker(void* pParam);
void    ConnectNatsServer(int bConnect);
void*   ThreadWorker(void* pParam);
void    ConnectCameraServer(int bConnect);


// -------------------------------------------------------------------
//  Global Variable
// -------------------------------------------------------------------
static  SWBOX*  pMM;

char    m_sLogDir[1024]         = {0};


#define m_MONITOR_INTERVAL      pMM->iReportInterval
///     m_iReportInterval       = 0;
int     m_iAlarmInterval        = 0;
int     m_iLogInterval          = 0;

int     m_bSubscribe            = FALSE;


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    TimerHandler();
void    PrintDevice(int hLog, char* pName, int iID);


// -------------------------------------------------------------------
//  Main Function : Websocket
// -------------------------------------------------------------------
int     main(int argc, char* argv[])
{
    pMM = SIO_Init();

    strcpy(pMM->xCI.sServerURL, "nats://nats2.highmaru.com:4222");
    SIO_InitAValve();           // DAC Init

    pMM->xSW[1].iOutVal = TRUE; // Write LED ON
    SIO_WriteLED();

    ParseArg(argc, argv);

    OpenLogFile(m_sLogDir, "main");
    LogPrintf("Boot : ==============================\n");
    LogPrintf("Boot :   SmartValve - NATS\n");
    LogPrintf("Boot : ==============================\n");

CONNECT:
    printf("Loading Default Rule\n");
    SIO_LoadDefaultRule(DEFAULT_FILE);
    printf("--------------------------------------------------\n");

    static  pthread_t   m_ble;
    m_ble = pthread_create( &m_ble, NULL, BleWorker, NULL );

#ifdef USE_MODBUS
    static  pthread_t   m_th;

    MBUS_Init(pMM, FALSE);
    MBUS_Open();

    m_th = pthread_create( &m_th, NULL, ModbusWorker, NULL );
#else
#endif

#ifdef USE_NATS_SERVER
    ConnectNatsServer(TRUE);

    while ( m_bSubscribe == FALSE ) {
        printf("Waiting Subscription\n");
        sleep(1);
    }

    while ( TRUE ) {
        char* p = SP_GetSID();

        if ( p[0] > 0 ) break;
        printf("Waiting Identification\n");
        sleep(1);
    }

    SP_CheckVersion();

    ConnectCameraServer(TRUE);  // UserID needed
#else
#endif

    printf("Main Loop Started\n");

    CreateTimerHandler(TimerHandler, LOOP_DELAY * 1000);

    while (TRUE) {
        sleep(1);
    }

#ifdef USE_NATS_SERVER
    ConnectNatsServer(FALSE);
#endif

    return(TRUE);
}


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void*   BleWorker(void* pParam)
{
    int     iOption;

    FIFO_InitFile();

    iOption = fcntl(pMM->hRFIFO, F_GETFL) & ~O_NONBLOCK;
    fcntl(pMM->hRFIFO, F_SETFL, iOption);

    while (TRUE) {
        if ( FIFO_Process(pMM) == FALSE ) {
            printf("FIFO Empty\n");
        }
    }
}


#ifdef USE_MODBUS
// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void*   ModbusWorker(void* pParam)
{
    while (TRUE) {
        MBUS_GetMode();

        sleep(10);
    }
}
#endif


#ifdef USE_NATS_SERVER
// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    ConnectNatsServer(int bConnect)
{
    static  pthread_t   m_th;
    static  int         h_th;
    static  int         status;

    if (bConnect == FALSE) {
        pthread_join(m_th, (void**)&status);
        return;
    }

/// fLog = fopen("/dev/null", "w");

    WriteQuitFile();

    m_th = pthread_create( &m_th, NULL, ThreadWorker, NULL );
}


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void*   ThreadWorker(void* pParam)
{
    int     iMonitorSent = 0;
    int     iAlarmSent   = 0;

    int     iStep = 1;
    int     iNACMD;
    int     iRet;

    int     hLog;

    hLog = OpenLogFile(m_sLogDir, "nats");

    NATS_Init(pMM, hLog);

    iRet = NATS_Connect(pMM->xCI.sServerURL, 0);
    if ( iRet < 0 )     return (NULL);

    NATS_ReadInfo();
    NATS_Send(NACMD_CONNECT);

    while (TRUE) {
        // ===================
        iNACMD = NATS_Read();
        // ===================

        if ( iNACMD == NACMD_PING ) {
            NATS_Send(NACMD_PONG);
            continue;
        }

        m_bSubscribe = TRUE;

        switch (iStep) {
        case 1:	NATS_Send(NACMD_SUB);		    // NC_Login     : SUB _INBOX
                iStep++;
                continue;
        case 2:	NATS_Send(NACMD_PUB_LOGIN);		// NC_Login     : PUB login
                iStep++;
                continue;
        case 3: NATS_Send(NACMD_SUB);           // NC_Subscribe : SUB ctrl
                iStep++;
                continue;
        }

        {
            if ( iNACMD == NACMD_MSG_ADDGROUP ) {
                NATS_Send(NACMD_MSG_ADDGROUP);
                continue;
            }

            if ( iNACMD == NACMD_MSG_DELGROUP ) {
                NATS_Send(NACMD_MSG_DELGROUP);
                continue;
            }

            if ( iNACMD == NACMD_MSG ) {
                NATS_Send(NACMD_PUB_STATUS);
                continue;
            }

            if ( iNACMD == NACMD_PUB_STATUS ) {
                NATS_Send(NACMD_PUB_STATUS);
                continue;
            }

            if ( pMM->iMonitorSend != iMonitorSent ) {
                NATS_Send(NACMD_PUB_MONITOR);
                iMonitorSent = pMM->iMonitorSend;
                continue;
            }

            if ( pMM->iAlarmSend != iAlarmSent ) {
                NATS_Send(NACMD_PUB_ALARM);
                iAlarmSent = pMM->iAlarmSend;
                continue;
            }
		}
	}
}
#endif


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    TimerHandler()
{
/// printf("Hello\n");
    static  int     hTLog       = 0;
    static  int     iExecTime   = -1;
    static  int     iLogTime    = -1;
    static  int     iAlarmTime  = -1;
    static  int     iMonitorTime= -1;
    static  int     iReconnectTime = -1;

    static  int     iRun = 0;

    int     iSecond;

    char    sLogLine[1024];

    if ( hTLog == 0 ) {
        hTLog = OpenLogFile(m_sLogDir, "timer");
    }

    /// ==============================
    iSecond = HAL_GetLocalTime();
    iRun++;
    /// ==============================

    /// Step1 : Switch / Sensor Action
    {
        printf("\n  * switch time is %04d (%02d:%02d:%02d)\n",
                    iSecond / 60,
                    iSecond / 3600, iSecond / 60 % 60 , iSecond % 60);
    }

    SIO_UpdateSwitchRule(FALSE);
    MBUS_GetMode();

    {
        RULE*   pR;

        pMM->xSW[1].iOutVal = iRun % 2;         // Blink LED

    /// pR = &(pMM->xSW[1].R[0]);   PrintDevice(hTLog, " LED", 1);

        pR = &(pMM->xSW[2].R[0]);   PrintDevice(hTLog, "  AV", 2);
        pR = &(pMM->xSW[3].R[0]);   PrintDevice(hTLog, "  DV", 3);
        pR = &(pMM->xSW[4].R[0]);   PrintDevice(hTLog, "COMP", 4);
        pR = &(pMM->xSW[5].R[0]);   PrintDevice(hTLog, " AIR", 5);
    }

    {
    /// char*   pLogSout    = SIO_WriteSwitchAll();
        char*   pLogLED     = SIO_WriteLED();
        char*   pLogAVout   = SIO_WriteAValve();
        char*   pLogDVout   = SIO_WriteDValve();
        char*   pLogComp    = SIO_WriteCompressor();
        char*   pLogAir     = SIO_WriteAirCleaner();

        usleep(LOOP_DELAY / 2 * USLEEP_DELAY);

        char*   pLogBTN     = SIO_ReadButton();
        char*   pLogAV      = SIO_ReadAValve();
        char*   pLogDV      = SIO_ReadDValve();
        char*   pLogPT      = SIO_ReadPressure();

        sprintf( sLogLine,  "LED[%s] AV[%s] DV[%s] CP[%s] AC[%s] | "
                        /// "BTN[%s] "
                            "AV[%s] DV[%s] PR[%s]  ##  "
                            "R[%d] A[%d]",
                            pLogLED, pLogAVout, pLogDVout, pLogComp,
                            pLogAir,
                        /// pLogBTN,
                            pLogAV, pLogDV, pLogPT,
                            pMM->iMonitorSend, pMM->iAlarmSend);

        printf("%3d:%s\n", iRun, sLogLine);
        printf("\n");
    }

    /// Step2 : Sensor Alarm Check

    if ( (iMonitorTime < 0) ) {
        iLogTime    = (iSecond / m_iLogInterval)     * m_iLogInterval;
        iAlarmTime  = (iSecond / m_iAlarmInterval)   * m_iAlarmInterval;
        iMonitorTime= (iSecond / m_MONITOR_INTERVAL) * m_MONITOR_INTERVAL;

        iReconnectTime = time(NULL) + pMM->xCI.iServerTimeout;
    }

    if ( (iSecond > iLogTime) ) {
        iLogTime    = (iLogTime + m_iLogInterval) % SECOND_PER_DAY;
    }

    if ( (iSecond > iAlarmTime + 0) && (pMM->bUSE_Sensor) ) {
        if ( SIO_CheckAlarmAll(FALSE) == FALSE ) {
            pMM->iAlarmSend++;
        }

        iAlarmTime  = (iAlarmTime + m_iAlarmInterval) % SECOND_PER_DAY;
    }

    if ( (iSecond > iMonitorTime + 30) ) {
        pMM->iMonitorSend++;

        iMonitorTime = (iMonitorTime + m_MONITOR_INTERVAL) % SECOND_PER_DAY;
    }

    // TODO: Reconect Check
}


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    PrintDevice(int hLog, char* pName, int iID)
{
    SW*     pSW = &(pMM->xSW[iID]);
    RULE*   pR  = &(pMM->xSW[iID].R[0]);

    switch (iID) {
    case 1:
    case 2:
    case 3: LogPrintfn(hLog,
                "%s : TYPE[%d]  OUT[%d]  RULE[%d(%d) %d(%d)]\n",
                pName,
                pSW->iActionType, pSW->iOutVal,
                pR->iValue, pR->iOnTime, pR->iOffValue, pR->iOffTime);
            break;
    case 4: LogPrintfn(hLog,
                "%s : TYPE[%d]  OUT[%d]  RULE[min %d lo(%d) hi(%d) max%d]\n",
                pName,
                pSW->iActionType, pSW->iOutVal,
                pR->iMin, pR->iLow, pR->iHigh, pR->iMax);
            break;
    case 5: LogPrintfn(hLog,
                "%s : TYPE[%d]  OUT[%d]  RULE[val(%d) time(%d) trig(%d)]\n",
                pName,
                pSW->iActionType, pSW->iOutVal,
                pR->iValue, pR->iOnTime, pR->iTrigSec);
            break;
    }
}


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
int     ParseArg(int argc, char* argv[])
{
    CONFIG* pCI = &(pMM->xCI);

    FILE*   f;
    char    sLine[1024];
    char*   pName;
    char*   pVal;
    char*   pON[] = {"OFF", "ON"};

    f = fopen(CONFIG_FILE, "r");
    while ( fgets(sLine, 1024, f) != NULL ) {
        pName   = strtok(sLine, " \t\r\n");
        pVal    = strtok(NULL, " \t\r\n");

    /// if ( !strcmp(pName, "id") )             strcpy(m_sControllerID, pVal);
        if ( !strcmp(pName, "model_name") )     strcpy(pCI->sModelName, pVal);

        if ( !strcmp(pName, "server_timeout") ) pCI->iServerTimeout= atoi(pVal);
        if ( !strcmp(pName, "report_interval") )m_MONITOR_INTERVAL = atoi(pVal);
        if ( !strcmp(pName, "alarm_interval") ) m_iAlarmInterval   = atoi(pVal);
        if ( !strcmp(pName, "log_interval") )   m_iLogInterval     = atoi(pVal);

        if ( !strcmp(pName, "log_dir") )        strcpy(m_sLogDir, pVal);
        if ( !strcmp(pName, "use_switch") )     pMM->bUSE_Switch   = atoi(pVal);
        if ( !strcmp(pName, "use_sensor") )     pMM->bUSE_Sensor   = atoi(pVal);
        if ( !strcmp(pName, "use_hvac") )       pMM->bUSE_HVAC     = atoi(pVal);
        if ( !strcmp(pName, "reaction_time") )  pCI->iReactionTime = atoi(pVal);

        if ( !strcmp(pName, "camera_url") )     strcpy(pCI->sCameraURL,  pVal);
        if ( !strcmp(pName, "camera_interval")) pCI->iCameraInterval
                                                                   = atoi(pVal);
    }
    fclose(f);

    {
        strcpy(pCI->sControllerMacID, NIO_GetMacAddress("wlan0"));
#ifdef CONTROLLER_ID
        strcpy(pCI->sControllerMacID, CONTROLLER_ID);
#endif
    }

    printf("\n");
    printf("==================================================\n");
    printf("    SmartValve Controller  (Version %s)\n", SWBOX_VERSION);
    printf("==================================================\n");

    printf("Controller Name : %s\n", pCI->sModelName);
    printf("  Controller ID : %s\n", pCI->sControllerMacID);
    printf("     IP Address : %s\n", NIO_GetNetworkIP((char*)NIO_IF_NAME));

    printf("     Server URL : %s\n", pCI->sServerURL);
    printf(" Server Timeout : %d\n", pCI->iServerTimeout);
    printf("Report Interval : %d\n", m_MONITOR_INTERVAL);
    printf(" Alarm Interval : %d\n", m_iAlarmInterval);
    printf("   Log Interval : %d\n", m_iLogInterval);
    printf("  Log Directory : %s\n", m_sLogDir);

    printf(" Switch Control : %s\n", pON[pMM->bUSE_Switch]);
    printf(" Sensor Control : %s\n", pON[pMM->bUSE_Sensor]);
    printf("   HVAC Control : %s\n", pON[pMM->bUSE_HVAC]);
    printf("  Reaction Time : %d\n", pCI->iReactionTime);
    printf("     Camera URL : %s\n", pCI->sCameraURL);
    printf("Camera Interval : %d\n", pCI->iCameraInterval);

    printf("--------------------------------------------------\n");
    printf("\n");

    return (TRUE);
}


#define QUIT_FILE           "quit_smart"
// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    WriteQuitFile()
{
    FILE*   f;

    remove(QUIT_FILE);

    f = fopen(QUIT_FILE, "w");
    if ( f == NULL )    printf("Fail to Write Quit File\n");

    fprintf(f, "./quit_camera\n");
    fprintf(f, "kill %d\n", getpid());
    fprintf(f, "rm -f %s\n", QUIT_FILE);
    fclose(f);

    chmod(QUIT_FILE, 0555);
}


// -------------------------------------------------------------------
//  Private Function
// -------------------------------------------------------------------
void    ConnectCameraServer(int bConnect)
{
    {
        struct  stat    buffer;

          if ( stat("/dev/video0", &buffer) != 0 ) {
            printf("Camera Device not found\n");
            return;
        }
    }

    FILE*   f = fopen("cam/camera.sh", "w");
    fprintf(f, "python CameraUpload.py %s %s %d\n",
                pMM->xCI.sCameraURL,
                SP_GetSID(),            // "user_id",
                pMM->xCI.iCameraInterval);
    fclose(f);

    sleep(1);
/// system("sh ./camera.sh &");

    char    sSystem[1024];
    sprintf(sSystem, "python cam/CameraUpload.py %s %s %d &",
                pMM->xCI.sCameraURL,
                SP_GetSID(),
                pMM->xCI.iCameraInterval);

    system(sSystem);
}
