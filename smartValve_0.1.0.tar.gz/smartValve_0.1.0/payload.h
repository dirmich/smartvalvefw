
/*********************************************************************
    payload.h  (Rev 0.80)

    SmartServer Payload interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
FILE*   SP_OpenLog(char* pLogFile);
int     SP_Init(void* pSWBOX, int hProtocolLog);

int     SP_Clear(int iNACMD);
int     SP_Decode(int iNACMD, char* pCommand, char* pData);

int     SP_SyncRule(int iCmd);

int     SP_Encode(int iNACMD, char* pCommand, char* pData);

char*   SP_GetSID();
char*   SP_GetGroup(int bFirst);
int     SP_GetNetworkType();
int     SP_CheckVersion();

char*   SP_BLE_Decode(char* pData);
char*   SP_BLE_GetItem(char* pKey);
