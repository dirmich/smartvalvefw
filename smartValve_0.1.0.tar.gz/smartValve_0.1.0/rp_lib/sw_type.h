/*********************************************************************
    sw_type.h (Rev 1.0)

    SwitchBox ADT

    Copyright(C) 2020-2023  Memorylab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

// -------------------------------------------------------------------
//  Type Definition
// -------------------------------------------------------------------
#define NETWORK_WIFI    1
#define NETWORK_LTE     2

#define FIFO_BLE_RD     "/tmp/FIFO_BLE_SIO"
#define FIFO_BLE_WR     "/tmp/FIFO_SIO_BLE"

#define LOG_LEN         256
#define RAW_LEN         64
#define FIFO_LEN        1024
#define MAX_SW          (8)
#define SW_ARRAY        (1 + 8)
#define MAX_SEN         (8)
#define SEN_ARRAY       (1 + 8)
#define MAX_RULE        (10)
#define SEN_READ_HIST   10

#define SW_RELAY        1
#define SW_VALVE        2

#define SEN_RELAY       1
#define SEN_VALVE       2


#define ACTION_STOP     0
#define ACTION_ALL      1
#define ACTION_DAY      2
#define ACTION_LOOP     3
#define ACTION_TRIG     4
#define ACTION_LOOPTRIG 5
#define ACTION_MINMAX   10


#define DEVID_SW_LED    1
#define DEVID_SW_AV     2
#define DEVID_SW_DV     3
#define DEVID_SW_COMP   4
#define DEVID_SW_AIR    5

#define DEVID_SEN_BTN   1
#define DEVID_SEN_AV    2
#define DEVID_SEN_DV    3
#define DEVID_SEN_COMP  4


typedef struct SEN_ {
    char    sLog[LOG_LEN];
    int     iDeviceType;        // Direct Control at WriteSwitchAll if RELAY

    char    sRaw[RAW_LEN];

    int     nRead;
    int     aiRead[SEN_READ_HIST];

    int     iAlarmHit;
    int     iHiLimit;
    int     iLoLimit;
    //
    int     bUseFeedBack;       // For feedback device
    int     bFeedbackError;
    int     bMinMaxError;
    int     iOutVal;
} SEN;


typedef struct RULE_ {
/// int     iActionType;
    int     iTrigOutSec;
    int     iTrigClearSec;

    int     iValue;
    int     iOffValue;
    int     iOnTime;
    int     iOffTime;
    int     iOnOffDuration;
    int     iTrigSec;
    int     iError;

    int     iMin;               // Type 10 only
    int     iLow;
    int     iHigh;
    int     iMax;
} RULE;


typedef struct SW_ {
    char    sLog[LOG_LEN];
    int     iDeviceType;
    int     iOutVal;

    int     iUpdateOut;
    int     iFeedbackTime;      // Last Out Change Time in second

    int     iActionType;        // 1:All  2:Day  3:Loop  4:Trig  5:LoopTrig  10:MinMax
    int     nRule;
    RULE    R[MAX_RULE];
    int     iErrorRate;         // Error Rate (Optional)
    //
    SEN*    pSEN;               // For feedback sensor device
} SW;


typedef struct CONFIG_ {
    char    sControllerMacID[256];
    char    sModelName[1024];
    char    sServerURL[1024];
    int     iServerTimeout;

    char    sCameraURL[1024];
    int     iCameraInterval;

    int     iReactionTime;

    int     iValveType;
/// char    sValveType[2][32];
} CONFIG;


typedef struct MODBUS_ {
    int     bLink;

    short   iSOC;
    short   iBatV;
    short   iBatC;
    short   iBatP;
    short   iSolV;
    short   iSolC;
    short   iSolP;
    short   iTemp;
} MODBUS;


typedef struct SWBOX_ {
    int     bServerLink;
    int     bCameraLink;

    int     bUSE_Switch;
    int     bUSE_Sensor;
    int     bUSE_HVAC;

    int     iReportInterval;

    /// =============================

    char    sI2C[FIFO_LEN + 1];
    char    sSPI[FIFO_LEN + 1];

    char    sCOM[FIFO_LEN + 1];
    int     iCOM;

    int     hRFIFO;
    int     hWFIFO;

    /// =============================

    SW      xSW[SW_ARRAY];
    SEN     xSEN[SEN_ARRAY];

    /// -----------------------------
    /// Application Interface for SmartValve
    /// -----------------------------

    CONFIG  xCI;
    MODBUS  xMBUS;

    /// -----------------------------
    /// Communication
    /// -----------------------------

    int     iMonitorSend;
    int     iAlarmSend;
}
SWBOX;
