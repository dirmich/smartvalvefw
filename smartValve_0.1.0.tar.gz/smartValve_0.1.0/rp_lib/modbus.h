/*********************************************************************
    modbus.h (Rev 0.90)

    MODBUS Processing Module

    Copyright(C) 2022  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __MODBUS_H__
#define __MODBUS_H__

#ifdef __cplusplus
extern "C" {
#endif


int     MBUS_Init(void* p, int bLog);
int     MBUS_Open();
int     MBUS_Test();

int     MBUS_Update();
int     MBUS_SetMode();
int     MBUS_GetMode();

#ifdef __cplusplus
}
#endif

#endif

