/*********************************************************************
    sconv.h (Rev 0.92)

    SwitchBox Processing Module

    Copyright(C) Memorylab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __SCONV_H__
#define __SCONV_H__

#ifdef __cplusplus
extern "C" {
#endif

int     SEN_ConvSensorRange();
char*	SEN_ConvADC();

int		SEN_ConvTemp(int iADC);
int		SEN_ConvPH(int iADC);
int		SEN_ConvCO2(int iADC);
int		SEN_ConvLumi(int iADC);

#ifdef __cplusplus
}
#endif

#endif

