
/*********************************************************************
    json.c  (Rev 0.80)

    JSON interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include <global.h>
#include "local.h"
#include <curl/curl.h>
#include "upload.h"


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     CURL_Upload(char* pFileName, char* pURL)
{
    FILE*       f;
    struct stat xFI;

    CURL*       hCURL;
    CURLcode    ret;

    f = fopen(pFileName, "rb");
    fstat(fileno(f), &xFI);

    hCURL = curl_easy_init();

//    list = curl_slist_append(list, "Content-Type: application/json"); // content-type 정의 내용 list에 저장 
//    curl_easy_setopt(hCURL, CURLOPT_HTTPHEADER, list); // content-type 설정
    
//    curl_easy_setopt(hCURL, CURLOPT_SSL_VERIFYPEER, 1L);
//    curl_easy_setopt(hCURL, CURLOPT_SSL_VERIFYHOST, 1L);

//    curl_easy_setopt(hCURL, CURLOPT_UPLOAD, 1L);
//    curl_easy_setopt(hCURL, CURLOPT_READDATA, f);
    curl_easy_setopt(hCURL, CURLOPT_POST, 1L);
    curl_easy_setopt(hCURL, CURLOPT_POSTFIELDS, f);

//    curl_easy_setopt(hCURL, CURLOPT_POSTFIELDS, "data");
    curl_easy_setopt(hCURL, CURLOPT_INFILESIZE_LARGE, (curl_off_t)xFI.st_size);
 
    curl_easy_setopt(hCURL, CURLOPT_VERBOSE, 1L);

    curl_easy_setopt(hCURL, CURLOPT_URL, pURL);

    ret = curl_easy_perform(hCURL);

//    curl_slist_free_all(list);


    fclose(f);

    return (TRUE);
}
