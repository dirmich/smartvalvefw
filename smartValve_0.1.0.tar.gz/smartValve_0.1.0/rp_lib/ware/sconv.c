/*********************************************************************
    swio.c (Rev 0.92)

    SwitchBox Processing Module

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include <global.h>
#include "local.h"
#include "sw_type.h"
#include "sconv.h"


// -------------------------------------------------------------------
//	Main Memory
// -------------------------------------------------------------------
extern	SWBOX*	pMM;


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SEN_ConvSensorRange()
{
	SEN*	pADC;

	for ( int i = 1 ; i < SEN_ARRAY ; i++ ) {
		pADC = &(pMM->xADC[i]);

	///	if ( pADC->iType == SEN_LUMI )
		if ( pADC->iType == SEN_TEMP )		{ pADC->iLo *=  10; pADC->iHi *=  10; }
		if ( pADC->iType == SEN_HUMI )		{ pADC->iLo *=  10; pADC->iHi *=  10; }
		if ( pADC->iType == SEN_PH   )		{ pADC->iLo *= 100; pADC->iHi *= 100; }
	///	if ( pADC->iType == SEN_CO2  )		
	}

	return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int		sen_NomalizeSensor(SEN* pADC)
{
	int		iSum 	= 0;
	int		iMin	= 0;
	int		iMax	= 0;	

	if ( pADC->iRing == 1 ) {
		for ( int i = 0 ; i < SEN_READRING ; i++ ) {
			pADC->aiRead[i] = pADC->aiRead[0];
		}
	}

	iMin = pADC->aiRead[0];
	iMax = pADC->aiRead[0];
	for ( int i = 0 ; i < SEN_READRING ; i++ ) {
		iSum += pADC->aiRead[i];

		if ( iMin > pADC->aiRead[i] )	iMin = pADC->aiRead[i];
		if ( iMax < pADC->aiRead[i] )	iMax = pADC->aiRead[i];
	}

	iSum = iSum - iMin - iMax;

	return ( iSum / (SEN_READRING - 2) );
}


#define ADC_SCALE	1024.0
#define LUMI_MAX	9000.0
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*    SEN_ConvADC()
{
	static	char	sLog[256];
	SEN*			pADC;
	int				iADC;
	float			f;

	// LUMI1
	pADC = pMM->pSEN_LUMI;
	iADC = sen_NomalizeSensor(pADC);
	pADC->fValue = (float)iADC * LUMI_MAX / ADC_SCALE;
	pADC->iValue = (int)pADC->fValue;
	sprintf(sLog, "Lumi[%d] ", pADC->iValue);

	pADC = pMM->pSEN_LUMI2;
	iADC = sen_NomalizeSensor(pADC);
	pADC->fValue = (float)iADC * LUMI_MAX / ADC_SCALE;
	pADC->iValue = (int)pADC->fValue;
	sprintf(sLog + strlen(sLog), "Lumi2[%d] ", pADC->iValue);

	pADC = pMM->pSEN_PH;
	f = 1000 * (sen_NomalizeSensor(pADC) - 365) * 3.3 / 59.16 / ADC_SCALE;
	pADC->fValue = f;
	pADC->iValue = (int)(pADC->fValue * 100);
	sprintf(sLog + strlen(sLog), "PH[%d] ", pADC->iValue);


	pMM->pSEN_CO2->iValue	= sen_NomalizeSensor( &(pMM->xExCO2) );
	pMM->pSEN_TEMP->iValue	= sen_NomalizeSensor( &(pMM->xExTEMP) );
	pMM->pSEN_HUMI->iValue	= sen_NomalizeSensor( &(pMM->xExHUMI) );

	return (sLog);
}


/// ------------------------------------------------------------------
/// Interface Function  (ETH-01DV)
/// ------------------------------------------------------------------
int     SEN_ConvTemp(int iADC)
{
	SEN*	pADC = &(pMM->xADC[iADC]);
	double	dADC = (double)(pADC->aiRead[0]);

	{
		dADC = -66.875 + 218.75 * (dADC / ADC_SCALE);
	}

	dADC = dADC * 10;

	pADC->iValue = (int)dADC;

	return ( pADC->iValue );
}


/// ------------------------------------------------------------------
/// Interface Function  (ETH-01DV)
/// ------------------------------------------------------------------
int     SEN_ConvHumi(int iADC)
{
	SEN*	pADC = &(pMM->xADC[iADC]);
	double	dADC = (double)(pADC->aiRead[0]);

	{
		dADC = -12.5 + 125 * (dADC / ADC_SCALE);
	}

	dADC = dADC * 10;

	pADC->iValue = (int)dADC;

	return ( pADC->iValue );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SEN_ConvPH(int iADC)
{
	return (0);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SEN_ConvCO2(int iADC)
{
	return (0);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SW_ConvLumi(int iADC)
{
	return (0);
}

