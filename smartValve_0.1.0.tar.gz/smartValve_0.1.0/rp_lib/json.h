
/*********************************************************************
    json.h  (Rev 0.90)

    JSON interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
#define MAX_JSON_TAG            100


typedef struct {
    char*   pKey;
    int     iKey;

    char*   pVal;
    int     iVal;
} JE;


typedef struct {
    char    sCopy[4096];

    int     nJE;
    JE      xJE[MAX_JSON_TAG];
} JSET;


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     JSON_Clear(JSET* pJS);
int     JSON_Print(JSET* pJS, FILE* fLog);
int     JSON_Decode(JSET* pJS, char* pBuffer);
char*   JSON_Key(JSET* pJS, int iPos);
char*   JSON_Val(JSET* pJS, int iPos);
char*   JSON_FindVal(JSET* pJS, int iBaseIndex, char* pKey);
int     JSON_FindPos(JSET* pJS, int iBaseIndex, char* pKey);
