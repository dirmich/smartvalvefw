/*********************************************************************
    modbus.c (Rev 0.90)

    MODBUS Processing Module

    Copyright(C) 2022  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#ifdef RASPBIAN
#else
#endif
#include "hal_type.h"
#include "hal.h"
#include "sw_type.h"
#include "sio.h"
#include "crc.h"
#include "modbus.h"


// -------------------------------------------------------------------
//  Main Memory
// -------------------------------------------------------------------
static  MODBUS* pMBUS;
static  FILE*   fLog = NULL;
static  char    sLog[256];


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     MBUS_Init(void* p, int bLog)
{
    SWBOX*  pMM = (SWBOX*)p;

    pMBUS = &(pMM->xMBUS);

    CRC_InitPoly(16, 0x80050000, 16);   // Modbus CRC

    HAL_WriteGPIO(GPIO_4, 0);           // Select UART MUX
    HAL_WriteGPIO(GPIO_5, 0);           // Select UART MUX

    if ( bLog == TRUE ) {
        fLog = fopen("./modbus.log", "w");
    }
    else {
        fLog = fopen("/dev/null", "w");
    }

    return (TRUE);
}


#define MODBUS_DEVADDR      1

#define MODBUS_REGREAD      3
#define MODBUS_REGREADS     4
#define MODBUS_REGWRITE     6
#define MODBUS_REGWRITES    16
/// ------------------------------------------------------------------
/// Interface Function
/// 01 03 00 32 00 04 e5 c6 ; HVAC
/// 01 04 33 1A 00 01 1F 49 ; BMS
/// ------------------------------------------------------------------
int     MBUS_Open()
{
    char    sMODBUS[100];
    int     iCRC;
    int     bDebug = TRUE;

    sMODBUS[0] = MODBUS_DEVADDR;
    sMODBUS[1] = MODBUS_REGREADS;
    sMODBUS[2] = 0x33;
    sMODBUS[3] = 0x1A;
    sMODBUS[4] = 0;
    sMODBUS[5] = 1;

    iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

    sMODBUS[6] = (iCRC % 256);
    sMODBUS[7] = (iCRC / 256) % 256;

    SIO_WriteModbus(bDebug, sMODBUS, 8, sLog);  fprintf(fLog, "%s", sLog);
    SIO_ReadModbus(bDebug, sMODBUS, 80, sLog);  fprintf(fLog, "%s", sLog);

    if ( (sMODBUS[0] == MODBUS_DEVADDR) && (sMODBUS[1] == MODBUS_REGREADS) ) {
        pMBUS->bLink = TRUE;
    }

    fflush(fLog);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     MBUS_Test()
{
    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     MBUS_Update()
{
/// MBUS_SetMode(pMM->xHVAC.iCmd, pMM->xHVAC.iCmdTemp, pMM->xHVAC.iCmdFan);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     MBUS_SetMode()
{
    if ( pMBUS->bLink == FALSE )        return (FALSE);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     MBUS_GetMode()
{
    char    sMODBUS[100];
    int     iCRC;
    int     bDebug = TRUE;

    if ( pMBUS->bLink == FALSE )        return (FALSE);

    {
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGREADS;
        sMODBUS[2] = 0x33;
        sMODBUS[3] = 0x1A;
        sMODBUS[4] = 0;
        sMODBUS[5] = 4;

        iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

        sMODBUS[6] = (iCRC % 256);
        sMODBUS[7] = (iCRC / 256) % 256;

        SIO_WriteModbus(bDebug, sMODBUS, 8, sLog);  fprintf(fLog, "%s", sLog);
        SIO_ReadModbus(bDebug, sMODBUS, 80, sLog);  fprintf(fLog, "%s", sLog);

        pMBUS->iBatV = (UCHAR)sMODBUS[3] * 256 + (UCHAR)sMODBUS[4];
        pMBUS->iBatC = (UCHAR)sMODBUS[5] * 256 + (UCHAR)sMODBUS[6];
    /// pMBUS->iTemp = (UCHAR)sMODBUS[7] * 256 + (UCHAR)sMODBUS[8];
        pMBUS->iTemp = (UCHAR)sMODBUS[9] * 256 + (UCHAR)sMODBUS[10];
    }

    {
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGREADS;
        sMODBUS[2] = 0x31;
        sMODBUS[3] = 0x00;
        sMODBUS[4] = 0;
        sMODBUS[5] = 3;

        iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

        sMODBUS[6] = (iCRC % 256);
        sMODBUS[7] = (iCRC / 256) % 256;

        SIO_WriteModbus(bDebug, sMODBUS, 8, sLog);  fprintf(fLog, "%s", sLog);
        SIO_ReadModbus(bDebug, sMODBUS, 80, sLog);  fprintf(fLog, "%s", sLog);

        pMBUS->iSolV = (UCHAR)sMODBUS[3] * 256 + (UCHAR)sMODBUS[4];
        pMBUS->iSolC = (UCHAR)sMODBUS[5] * 256 + (UCHAR)sMODBUS[6];
        pMBUS->iSolP = (UCHAR)sMODBUS[7] * 256 + (UCHAR)sMODBUS[8];
    }

    {
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGREADS;
        sMODBUS[2] = 0x31;
        sMODBUS[3] = 0x1A;
        sMODBUS[4] = 0;
        sMODBUS[5] = 1;

        iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

        sMODBUS[6] = (iCRC % 256);
        sMODBUS[7] = (iCRC / 256) % 256;

        SIO_WriteModbus(bDebug, sMODBUS, 8, sLog);  fprintf(fLog, "%s", sLog);
        SIO_ReadModbus(bDebug, sMODBUS, 80, sLog);  fprintf(fLog, "%s", sLog);

        pMBUS->iSOC  = (UCHAR)sMODBUS[3] * 256 + (UCHAR)sMODBUS[4];
    }

    fprintf(fLog, "SOLV:%d  SOLC:%d  SOLP:%d  SOC:%d\n", pMBUS->iSolV, pMBUS->iSolC, pMBUS->iSolP, pMBUS->iSOC);

    fflush(fLog);

    return (TRUE);
}
