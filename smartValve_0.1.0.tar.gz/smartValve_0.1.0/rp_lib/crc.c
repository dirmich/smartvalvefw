/*********************************************************************
    CRC.c (Rev 0.90)

    CRC Processing Module

    Copyright(C) 2020  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "crc.h"


int     m_iPoly[MAX_CRC];
int     m_iSize[MAX_CRC];
int     m_iLUT[MAX_CRC][256];


int     CRC_GenerateLUT(int iHandle);


int     m_16[] = {
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
    0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef };
//--------------------------------------------------------------------
//  Function Definition
//--------------------------------------------------------------------
int     CRC_Test(char* pSource, int iSource)
{
    UCHAR*  puSource = (UCHAR*)pSource;
    int     iCRC;
    int     i;
    int     j;
    char*   pp = (char*)&(m_iLUT[32][0]);

    iCRC    = 0;

    for ( i = 0 ; i < iSource ; i++ ) {
        if ( i == 0 ) {
            j       = ((puSource[0] >> 4) & 0x0f);
            iCRC    = (m_16[j] ^ (iCRC <<  4));

            j       = ( ((puSource[0] >> 0) & 0x0f) ^ (iCRC >> 12) ) & 0x0f;
            iCRC    = (m_16[j] ^ (iCRC <<  4));
        }
        else {
            j       = ( ((puSource[i] >> 4) & 0x0f) ^ (iCRC >> 12) ) & 0x0f;
            iCRC    = (m_16[j] ^ (iCRC <<  4));

            j       = ( ((puSource[i] >> 0) & 0x0f) ^ (iCRC >> 12) ) & 0x0f;
            iCRC    = (m_16[j] ^ (iCRC <<  4));
        }
    }

    return (iCRC);
}


//--------------------------------------------------------------------
//  Function Definition
//--------------------------------------------------------------------
int     CRC_InitPoly(int iHandle, int iPoly, int iBitSize)
{
    m_iPoly[iHandle] = iPoly;
    m_iSize[iHandle] = iBitSize;

    CRC_GenerateLUT(iHandle);

    if ( iHandle == 16 ) {
        CRC_Test("ABCDEFGH", 8);
    }

    return (iHandle);
}


//--------------------------------------------------------------------
//  Function Definition
//--------------------------------------------------------------------
int     CRC_Calc(int iHandle, char* pSource, int iSource)
{
    UCHAR*  puSource = (UCHAR*)pSource;
    int     iCRC;
    int     i;
    int     j;
    char*   pp = (char*)&(m_iLUT[32][0]);

    iCRC    = 0;

    for ( i = 0 ; i < iSource ; i++ ) {
        if ( i == 0 ) {
            j       = puSource[0];
            iCRC    = m_iLUT[iHandle][j];
        }
        else {
            j       = (puSource[i]        ^ (iCRC >> 24)) & 0xff;
            iCRC    = (m_iLUT[iHandle][j] ^ (iCRC <<  8));
        }
    }

    if ( m_iSize[iHandle] ==  4 )   iCRC = (iCRC >> 28) & 0x0000000f;
    if ( m_iSize[iHandle] ==  8 )   iCRC = (iCRC >> 24) & 0x000000ff;
    if ( m_iSize[iHandle] == 16 )   iCRC = (iCRC >> 16) & 0x0000ffff;
    if ( m_iSize[iHandle] == 32 )   iCRC = (iCRC >>  0) & 0xffffffff;

    return (iCRC);
}


//--------------------------------------------------------------------
//  Function Definition
//--------------------------------------------------------------------
int     CRC_CalcEx(int iHandle, char* pSource, int iSource, int iInitVal, int bSrcRev, int bOutRev)
{
    char    sREV[] = {  0x0, 0x8, 0x4, 0xc, 0x2, 0xa, 0x6, 0xe,
                        0x1, 0x9, 0x5, 0xd, 0x3, 0xb, 0x7, 0xf, };
    char    sCopy[1000];

/// UCHAR*  puSource = (UCHAR*)pSource;
    UCHAR*  puSource = (UCHAR*)sCopy;
    int     iCRC;
    UCHAR   sCRC[4];
    UCHAR   sOUT[4];
    int     i;
    int     j;
    char*   pp = (char*)&(m_iLUT[32][0]);

    iCRC    = 0;
    iCRC    = iInitVal;
    if ( m_iSize[iHandle] ==  4 )   iCRC = (iInitVal & 0xf0000000);
    if ( m_iSize[iHandle] ==  8 )   iCRC = (iInitVal & 0xff000000);
    if ( m_iSize[iHandle] == 16 )   iCRC = (iInitVal & 0xffff0000);
    if ( m_iSize[iHandle] == 32 )   iCRC = (iInitVal & 0xffffffff);

    for ( i = 0 ; i < iSource ; i++ ) {
        sCopy[i] = (bSrcRev == TRUE) ? (sREV[pSource[i] % 16] << 4) + sREV[pSource[i] / 16] : pSource[i];
    }

    for ( i = 0 ; i < iSource ; i++ ) {
        j       = (puSource[i]        ^ (iCRC >> 24)) & 0xff;
        iCRC    = (m_iLUT[iHandle][j] ^ (iCRC <<  8));
    }

    if ( bOutRev == TRUE ) {
        *(int*)sCRC = iCRC;

        for ( int i = 0 ; i < 4 ; i++ ) {
            sCRC[i] = (sREV[sCRC[i] % 16] << 4) + sREV[sCRC[i] / 16];
        }

        sOUT[0] = sCRC[3];
        sOUT[1] = sCRC[2];
        sOUT[2] = sCRC[1];
        sOUT[3] = sCRC[0];

        iCRC = *(int*)sOUT;

        if ( m_iSize[iHandle] ==  4 )   iCRC = (iCRC << 28);
        if ( m_iSize[iHandle] ==  8 )   iCRC = (iCRC << 24);
        if ( m_iSize[iHandle] == 16 )   iCRC = (iCRC << 16);
        if ( m_iSize[iHandle] == 32 )   iCRC = (iCRC <<  0);
    }

    if ( m_iSize[iHandle] ==  4 )   iCRC = (iCRC >> 28) & 0x0000000f;
    if ( m_iSize[iHandle] ==  8 )   iCRC = (iCRC >> 24) & 0x000000ff;
    if ( m_iSize[iHandle] == 16 )   iCRC = (iCRC >> 16) & 0x0000ffff;
    if ( m_iSize[iHandle] == 32 )   iCRC = (iCRC >>  0) & 0xffffffff;

    return (iCRC);
}


//--------------------------------------------------------------------
//  Function Definition
//--------------------------------------------------------------------
int     CRC_GenerateLUTx(int iHandle)
{
    iHandle = 2;
    m_iPoly[iHandle] = 0x10210000;

    int     iCRC;
    int     i;
    int     j;
    char*   pp = (char*)&(m_iLUT[iHandle][0]);

    for ( i = 0 ; i < 16 ; i++ ) {
        iCRC    = (i << 28);
        if ( i == 4 ) {
            i = 4;
        }

        for ( j = 0 ; j < 4 ; j++ ) {
            iCRC    = (iCRC & 0x80000000) ? ((iCRC << 1) ^ m_iPoly[iHandle]) : (iCRC << 1);
        }

        m_iLUT[iHandle][i] = iCRC;
    }

    return (TRUE);
}


int     CRC_GenerateLUT(int iHandle)
{
    int     iCRC;
    int     i;
    int     j;
    char*   pp = (char*)&(m_iLUT[32][0]);

    for ( i = 0 ; i < 256 ; i++ ) {
        iCRC    = (i << 24);

        for ( j = 0 ; j < 8 ; j++ ) {
            iCRC    = (iCRC & 0x80000000) ? ((iCRC << 1) ^ m_iPoly[iHandle]) : (iCRC << 1);
        }

        m_iLUT[iHandle][i] = iCRC;
    }

    return (TRUE);
}
