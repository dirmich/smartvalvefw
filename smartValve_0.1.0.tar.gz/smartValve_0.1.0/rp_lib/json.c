/*********************************************************************
    json.c  (Rev 0.90)

    JSON interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "json.h"


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     JSON_Clear(JSET* pJS)
{
    memset( pJS, 0, sizeof(JSET) );

    pJS->sCopy[0] = 0;
    pJS->nJE = 0;

    return (TRUE);
}

#define CH_NUL                  0x80
#define CH_COL                  0x82
// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     JSON_Print(JSET* pJS, FILE* fLog)
{
/// ====================================
//  if (TRUE)           return (TRUE);
/// ====================================

    JE*     pJE;

    fprintf(fLog, " Count is %d\n",  pJS->nJE);

    fprintf(fLog, "String is ");
    for ( int i = 0 ; i < strlen(pJS->sCopy) ; i++ ) {
        char    cOut = pJS->sCopy[i];

        if ( cOut == CH_NUL )   cOut = ' ';
        if ( cOut == CH_COL )   cOut = ':';

        fprintf(fLog, "%c", cOut);
    }
    fprintf(fLog, "\n\n");

    for ( int i = 0 ; i < pJS->nJE ; i++ ) {
        pJE = &(pJS->xJE[i]);
        if ( pJE->iKey > 0 )    pJE->pKey[pJE->iKey] = 0;
        if ( pJE->iVal > 0 )    pJE->pVal[pJE->iVal] = 0;

        fprintf(fLog, "[%d]  %20s    %s\n",
                i, pJS->xJE[i].pKey, pJS->xJE[i].pVal);
    }

    return (TRUE);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     JSON_Decode(JSET* pJS, char* pString)
{
    JE*     pJE     = pJS->xJE;
    char*   pCopy   = pJS->sCopy;
    char    c;
    char    b;

    int     iString = strlen(pString);

    int     bQuote  = FALSE;
    for ( int i = 0 ; i < iString ;i++ ) {
        c = pString[i];
        b = (i == 0) ? 0 : pString[i-1];

        if ( (c == '"') )   bQuote = 1 - bQuote;

        if ( (c == '"') && (b != '"') )             continue;

        if ( (c == '"') && (b == '"') )             c = CH_NUL;

        if ( (c == ':') && ( bQuote == FALSE) )     c = CH_COL;
        if ( (c == ':') && ( bQuote == FALSE) )     c = CH_COL;

        pCopy[0] = c;
        pCopy++;
    }

    pCopy[0] = 0;

    memset(pJE, 0, sizeof(pJS->xJE));
    pJS->nJE = 0;

    char*   pHead   = pJS->sCopy;
    int     iLength = strlen(pHead);

    int     iBrace  = 0;
    int     i       = 0;
    int     j;
    while ( i < iLength ) {
        /// SKIP Leading
        while ( (pHead[i] == '{') || (pHead[i] == '}') ||
                (pHead[i] == '[') || (pHead[i] == ']') || (pHead[i] == ',') ) {
            i++;
        }

        /// KEY
        {
            j = i;
            while ( j < iLength ) {
                if ( pHead[j] == CH_COL )   break;
                j++;
            }

            pJE->pKey = pHead + i;
            pJE->iKey = j - i;

            i = j;
        }
        {
            int     iTrim = 0;
            for ( int k = 0 ; k < pJE->iKey ; k++ ) {
                if ( pJE->pKey[k] == '}' )  iTrim = k + 1;
                if ( pJE->pKey[k] == ']' )  iTrim = k + 1;
                if ( pJE->pKey[k] == ',' )  iTrim = k + 1;
            }

            if ( iTrim > 0 ) {
                pJE->pKey += iTrim;
                pJE->iKey -= iTrim;
            }
        }

        /// COL
        if ( pHead[i] == CH_COL ) {
            i++;
        }

        /// VAL
        if ( (pHead[i] == '{') || (pHead[i] == '[') ) {
            iBrace = 1;
            j = i + 1;
            while ( j < iLength ) {
                if ( pHead[j] == '{' )    iBrace++;
                if ( pHead[j] == '[' )    iBrace++;
                if ( pHead[j] == '}' )    iBrace--;
                if ( pHead[j] == ']' )    iBrace--;

            /// if ( pHead[j] == '}' )    break;
                if ((pHead[j] == '}') && (iBrace == 0) )    break;
                if ((pHead[j] == ']') && (iBrace == 0) )    break;
                j++;
            }

            pJE->pVal = pHead + i;
            pJE->iVal = j - i + 1;

        /// i = j;

            pJE++;
            pJS->nJE++;
        }
        else
        {
            j = i + 1;
            while ( j < iLength ) {
                if ( pHead[j] == '}' )    break;
                if ( pHead[j] == ']' )    break;
                if ( pHead[j] == ',' )    break;
                j++;
            }

            pJE->pVal = pHead + i;
            pJE->iVal = j - i;

            i = j;

            pJE++;
            pJS->nJE++;
        }

        /// SEP
        while ( (pHead[i] == '}') || (pHead[i] == ']') ) {
            i++;
        }
    }

    return (TRUE);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
char*   JSON_Key(JSET* pJS, int iPos)
{
    return (pJS->xJE[iPos].pKey);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
char*   JSON_Val(JSET* pJS, int iPos)
{
    return (pJS->xJE[iPos].pVal);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
char*   JSON_FindVal(JSET* pJS, int iBaseIndex, char* pKey)
{
    for ( int i = iBaseIndex ; i < pJS->nJE ; i++ ) {
        if ( !strcmp(pJS->xJE[i].pVal, "{}") ) {
            return (NULL);
        }

        if ( !strncmp(pJS->xJE[i].pKey, pKey, strlen(pKey)) ) {
            pJS->xJE[i].pVal[ pJS->xJE[i].iVal ] = 0;       // Overwrite NULL char

            return ( pJS->xJE[i].pVal );
        }
    }

    return (NULL);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     JSON_FindPos(JSET* pJS, int iBaseIndex, char* pKey)
{
    for ( int i = iBaseIndex ; i < pJS->nJE ; i++ ) {
        if ( !strncmp(pJS->xJE[i].pKey, pKey, strlen(pKey)) ) {
            pJS->xJE[i].pVal[ pJS->xJE[i].iVal ] = 0;       // Overwrite NULL char

            return (i);
        }
    }

    return (-1);
}
