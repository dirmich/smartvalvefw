/*********************************************************************
    HVAC.h (Rev 0.90)

    HVAC Processing Module

    Copyright(C) 2022  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __HVAC_H__
#define __HVAC_H__

#ifdef __cplusplus
extern "C" {
#endif

#define HVAC_MODE_STOP          0
#define HVAC_MODE_AUTO          10
#define HVAC_MODE_COOL          11
#define HVAC_MODE_DRY           12
#define HVAC_MODE_WIND          13
#define HVAC_MODE_HEAT          14

#define HVAC_FAN_AUTO           10
#define HVAC_FAN_LOW            11
#define HVAC_FAN_MID            12
#define HVAC_FAN_HIGH           13


int     HVAC_Init(void* p);
int     HVAC_Open();
int     HVAC_Update();
int     HVAC_SetMode(int iMode, int iVal, int iFan);
int     HVAC_GetMode(int* riRun, int* riMode, int* riVal, int* riFan);

#ifdef __cplusplus
}
#endif

#endif

