python CameraUpload.py https://remote.komoto.co.kr:3000/api/image/upload 65335dc7a6acd0bd85616449 600
