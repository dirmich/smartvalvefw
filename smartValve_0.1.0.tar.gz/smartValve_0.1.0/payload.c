/*********************************************************************
    payload.c  (Rev 0.80)

    SmartServer Payload interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "json.h"
#include "nats.h"
#include "payload.h"
#include "sw_type.h"
#include "sio.h"
#include "nio.h"


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
#define MAX_NATS_MESSAGE        16

typedef struct {
    JSET    xJS[MAX_NATS_MESSAGE];
} JA;


// -------------------------------------------------------------------
//    Nats Action
// -------------------------------------------------------------------
#define SERVER_SETRULE          3
#define SERVER_STATUS           4
#define SERVER_INBOX_STR        "_INBOX"
#define SERVER_SETRULE_STR      "setrule"
#define SERVER_STATUS_STR       "status"
#define SERVER_GROUPLIST        9

#define CLIENT_REPLY            10
#define CLIENT_REPORT           11
#define CLIENT_ALARM            12
#define CLIENT_REPLY_STR        "status"
#define CLIENT_REPORT_STR       "status"
#define CLIENT_ALARM_STR        "alarm"

#define CLIENT_BLE              15


// -------------------------------------------------------------------
//    Global Variable
// -------------------------------------------------------------------
static  FILE*   m_fLog  = NULL;
static  char    m_sSID[1024];

static  JA      xJA;
static  JA*     pJA = &(xJA);
static  SWBOX*  pMM;
static  int     hLog;


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
FILE*    SP_OpenLog(char* pLogFile)
{
/// m_fLog = freopen(pLogFile, "a+", stdout);
    m_fLog = fopen(pLogFile, "a+");

    setbuf(m_fLog, NULL);

    return (m_fLog);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_Init(void* pSWBOX, int hProtocolLog)
{
    if ( m_fLog == NULL ) {
        m_fLog = fopen("/dev/null", "w");
        m_fLog = stdout;
    }

    pMM = (SWBOX*)pSWBOX;

    memset(pJA, 0, sizeof(JA));

    hLog = hProtocolLog;

    return (TRUE);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_Clear(int iNACMD)
{
    return ( JSON_Clear( &(pJA->xJS[iNACMD]) ) );
}


#define STR_KEY_ID              "_id"
#define STR_KEY_GID             "gid"
#define STR_KEY_GROUP           "group"


int     sp_DecodeSwitchRule(int iDevID, int iCmd, int iRule);
int     sp_DecodeSensorRule(int iDevID, int iCmd, int iRule);
int     sp_DecodeTimeSet(char* pTimeStr, int* piVal);
// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_Decode(int iNACMD, char* pCommand, char* pData)
{
    JSET*   pJS = &(pJA->xJS[iNACMD]);
    char*   pVal;

    /// ============================
    JSON_Decode(pJS, (char*)pData);
    JSON_Print(pJS, m_fLog);
    /// ============================

    /// ctrl.1234567890.>

    if ( pCommand != NULL ) {
        char*   p = strchr(pCommand, ' ');
        p[0] = 0;
    }

    char*   pID     = (pCommand == NULL) ? NULL : strchr(pCommand,    '.');
    char*   pAction = (pID      == NULL) ? NULL : strchr(pID     + 1, '.');
    char*   pGID    = (pAction  == NULL) ? NULL : strchr(pAction + 1, '.');
    int     iAction = 0;

    if ( pID != NULL )          { pID[0]= 0;        pID++;      }
    if ( pAction != NULL )      { pAction[0]= 0;    pAction++;  }

    if ( iNACMD == NACMD_MSG ) {
        if ( !strcmp(pCommand, SERVER_INBOX_STR) )      iAction = SERVER_SETRULE;

        if ( !strcmp(pAction, SERVER_SETRULE_STR) )     iAction = SERVER_SETRULE;
        if ( !strcmp(pAction, SERVER_STATUS_STR) )      iAction = SERVER_STATUS;
    }

    switch (iAction) {
    case SERVER_SETRULE:SP_SyncRule(iNACMD);
                        pVal = JSON_FindVal( pJS, 0, STR_KEY_ID );
                        if (pVal) {
                            strcpy(m_sSID, pVal);
                            LogPrintfn(hLog, "NEW SID is %s\n", m_sSID);
                        }
                        break;

    case SERVER_STATUS: // TODO
                        break;
    }

    return (iAction);
}

// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
char*   SP_BLE_Decode(char* pData)
{
    JSET*   pJS = &(pJA->xJS[CLIENT_BLE]);

    int     iCmd;
    int     iBase;
    int     iPos;

    /// ============================
    JSON_Decode(pJS, (char*)pData);
    /// ============================

/// SP_SyncRule(CLIENT_BLE);

    iBase   = JSON_FindPos(pJS, 0,  "switch");
    if ( iBase >= 0 ) {
        iCmd    = CLIENT_BLE;

        iPos    = JSON_FindPos(pJS, iBase, "led"    );  sp_DecodeSwitchRule(11, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "avalve" );  sp_DecodeSwitchRule(12, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "dvalve" );  sp_DecodeSwitchRule(13, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "pump"   );  sp_DecodeSwitchRule(14, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "cleaner");  sp_DecodeSwitchRule(15, iCmd, iPos);
    }

    return ( JSON_Key(pJS, 0) );
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
char*   SP_BLE_GetItem(char* pKey)
{
    JSET*   pJS = &(pJA->xJS[CLIENT_BLE]);

    return ( JSON_FindVal(pJS, 0, pKey) );
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_SyncRule(int iCmd)
{
    JSET*   pJS = &(pJA->xJS[iCmd]);

    int     iBase;
    int     iPos;
    char*   pValue;

    iBase   = JSON_FindPos(pJS, 0,  "config");
    if ( iBase >= 0 ) {
        LogPrintfn(hLog, "    CONFIG =========\n");
        pValue  = JSON_FindVal(pJS, iBase, "reactiontime");
        if ( pValue != NULL ) {
            pMM->xCI.iReactionTime  = atoi(pValue);
        }
        pValue  = JSON_FindVal(pJS, iBase, "reportinterval");
        if ( pValue != NULL ) {
            pMM->iReportInterval = atoi(pValue);
        }
        pValue  = JSON_FindVal(pJS, iBase, "camerainterval");
        if ( pValue != NULL ) {
            pMM->xCI.iCameraInterval = atoi(pValue);
        }
    }

    iBase   = JSON_FindPos(pJS, 0,  "switch");
    if ( iBase >= 0 ) {
        LogPrintfn(hLog, "    SWITCH =========\n");
        iPos    = JSON_FindPos(pJS, iBase, "led"    );  sp_DecodeSwitchRule(11, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "avalve" );  sp_DecodeSwitchRule(12, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "dvalve" );  sp_DecodeSwitchRule(13, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "pump"   );  sp_DecodeSwitchRule(14, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "cleaner");  sp_DecodeSwitchRule(15, iCmd, iPos);

        iPos    = JSON_FindPos(pJS, iBase, "avalve" );  if ( iPos > 0 ) pMM->xCI.iValveType = 0;
        iPos    = JSON_FindPos(pJS, iBase, "dvalve" );  if ( iPos > 0 ) pMM->xCI.iValveType = 1;
    }

    iBase   = JSON_FindPos(pJS, 0,  "sensor");
    if ( iBase >= 0 ) {
        LogPrintfn(hLog, "    SENSOR =========\n");
        iPos    = JSON_FindPos(pJS, iBase, "button" );  sp_DecodeSensorRule(31, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "avalve" );  sp_DecodeSensorRule(32, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "dvalve" );  sp_DecodeSensorRule(33, iCmd, iPos);
        iPos    = JSON_FindPos(pJS, iBase, "pressure"); sp_DecodeSensorRule(34, iCmd, iPos);
    }

    return (TRUE);
}


int     iaTime[300];
// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     sp_DecodeSwitchRule(int iDevID, int iCmd, int iRule)
{
    JSET*   pJS = &(pJA->xJS[iCmd]);

    // -----------------------------------------
    if ( iRule < 0 )        return (FALSE);
    // -----------------------------------------

/// JSON_Print(pJS, stdout);

    char*   pType;
    char*   pData;
    char*   pError;
    char*   pValue  = NULL;  // BLE

    int     iType;
    int     iTime;
/// int     iaTime[300];
    int     iError;

    LogPrintfn(hLog, "    Dev[%d] RulePos[%d] %s\n",
                    iDevID, iRule, pJA->xJS[iCmd].xJE[iRule].pVal);

    pType   = JSON_FindVal(pJS, iRule, "type");
    pData   = JSON_FindVal(pJS, iRule, "data");
    pError  = JSON_FindVal(pJS, iRule, "error");

    if ( (pValue == NULL) && (pType == NULL) ) {        // ACTION_STOP
        SIO_LoadLiveSwitchRule(iDevID, 0, 0, 0, 0);
    }
    else
    if ( (pValue == NULL) ) {                           // ACTION_****
        iType   = atoi(pType);
        iTime   = sp_DecodeTimeSet(pData, iaTime);
        iError  = (pError == NULL) ? 0 : atoi(pError);

        SIO_LoadLiveSwitchRule(iDevID, iType, iTime, iaTime, iError);
    }
    else {
        iaTime[0] = atoi(pValue);
        iaTime[1] = 0;
        iaTime[2] = 2;

        SIO_LoadLiveSwitchRule(iDevID, 1, 3, iaTime, 0);
    }

    return(0);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     sp_DecodeSensorRule(int iDevID, int iCmd, int iRule)
{
    JSET*   pJS = &(pJA->xJS[iCmd]);

    // -----------------------------------------
    if ( iRule < 0 )        return (FALSE);
    // -----------------------------------------

    char*   pData   = pJA->xJS[iCmd].xJE[iRule].pVal;
    char*   pValue  = NULL;  // BLE

    int     iTime;
/// int     iaTime[300];
    int     iError;

    LogPrintfn(hLog, "    Sen[%d] RulePos[%d] %s    ", iDevID, iRule, pData);

    if ( pValue == NULL ) {
        iTime   = sp_DecodeTimeSet(pData, iaTime);

        LogPrintfn(hLog, "    Range Str with ");
        for ( int i = 0 ; i < iTime ; i++ ) {
            LogPrintfn(hLog,  "%d  ", iaTime[i]);
        }
        LogPrintfn(hLog,  "\n");

        if ( iTime > 0 ) {
            SIO_LoadLiveSensorRule(iDevID, iaTime[0], iaTime[1]);
        }
    }
    else {
        // BLE Support
    }

    return(0);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     sp_DecodeTimeSet(char* pTimeStr, int* piVal)
{
    int     iSet    = 0;
    int     iRead;

    // -----------------------------------------
    if ( pTimeStr == NULL ) return (iSet);
    // -----------------------------------------

    iRead = -1;
    while ( pTimeStr[0] > 0 ) {
        if ( (pTimeStr[0] >= '0') && (pTimeStr[0] <= '9') ) {
            if ( iRead == -1 ) {
                iRead = (pTimeStr[0] - '0');
            }
            else {
                iRead = iRead * 10 + (pTimeStr[0] - '0');
            }

        }
        else {
            if ( iRead == -1 ) {
                // Do Nothing
            }
            else {
                piVal[iSet] = iRead;
                iRead = -1;
                iSet++;
            }
        }

        pTimeStr++;
    }

    if ( iRead >= 0 ) {
        piVal[iSet] = iRead;
        iRead = -1;
        iSet++;
    }

    return (iSet);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_Encode(int iNACMD, char* pCommand, char* pData)
{
    char*   pLength;
    char*   pPayload;

    char    s1[256];
    char    s2[256];
    char    s3[256];
    char*   p;

    switch (iNACMD) {
    case NACMD_PUB_STATUS:      sprintf(pCommand,  "reply.%s.%s", SP_GetSID(), CLIENT_REPORT_STR);
                                break;
    case NACMD_PUB_MONITOR:     sprintf(pCommand,  "server.%s.%s", CLIENT_REPORT_STR, SP_GetSID());
                                break;

    case NACMD_PUB_ALARM: //    if ( pMM->iAlarmSend == pMM->iAlarmRecv )       return (FALSE);
                          //    pMM->iAlarmRecv = pMM->iAlarmSend;
                                sprintf(pCommand,  "server.%s.%s", CLIENT_REPORT_STR, SP_GetSID());
                                break;
    }

    pLength     = pCommand + strlen(pCommand);

    pPayload    = strcat(pLength, " 9999" "\r\n");
    pPayload   += strlen(pPayload);

    memset(s1, 0, 256);
    memset(s2, 0, 256);
    memset(s3, 0, 256);

    switch (iNACMD) {
    case NACMD_PUB_STATUS:
    case NACMD_PUB_MONITOR:
    {
        p = s1;                 sprintf(p, "'avalve':'%d',",    pMM->xSW[2].iOutVal );
        p = p + strlen(p);      sprintf(p, "'dvalve':'%d',",    pMM->xSW[3].iOutVal );
        p = p + strlen(p);      sprintf(p, "'pump':'%d',",      pMM->xSW[4].iOutVal );
        p = p + strlen(p);      sprintf(p, "'cleaner':'%d',",   pMM->xSW[5].iOutVal );

        p = s2;                 sprintf(p, "'avalve':'%d',",    pMM->xSEN[2].aiRead[0] / 100);
        p = p + strlen(p);      sprintf(p, "'dvalve':'%d',",    pMM->xSEN[3].aiRead[0] );
        p = p + strlen(p);      sprintf(p, "'pressure':'%d',",  pMM->xSEN[4].aiRead[0] / 100);

        s1[strlen(s1) - 1] = 0; // Erase last comma
        s2[strlen(s2) - 1] = 0; // Erase last comma

    /// if ( pMM->xMBUS.bLink == TRUE ) {
        if ( TRUE ) {
            MODBUS*    pM = &(pMM->xMBUS);

            sprintf(s3, "'soc':'%d','batv':'%d','batc':'%d','solv':'%d','solc':'%d','solp':'%d','temp':'%d'",
                    pM->iSOC, pM->iBatV, pM->iBatC, pM->iSolV, pM->iSolC, pM->iSolP, pM->iTemp);

            sprintf(pPayload, "{'_id':'%s','networktype':'%d','switch':{%s},'sensor':{%s},'bms':{%s}}",
                    SP_GetSID(), SP_GetNetworkType(), s1, s2, s3);
        }
        else {
            sprintf(pPayload, "{'_id':'%s','switch':{%s},'sensor':{%s}}", SP_GetSID(), s1, s2);
        }

        break;
    }

    case NACMD_PUB_ALARM:
        strcpy(pPayload, "Sensor Alarm");
        break;
    }



    sprintf(pLength, "%5d", strlen(pPayload) );
    pLength[5] = '\r';          // Glue Following String Again

    for ( int i = 0 ; i < strlen(pPayload) ; i++ ) {
        if ( pPayload[i] == '\'' )  pPayload[i] = '\"';
    }

    strcat(pPayload, "\r\n");

    return (TRUE);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
char*   SP_GetSID()
{
    return (m_sSID);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
char*   SP_GetGroup(int bFirst)
{
    JSET*   pJS = &(pJA->xJS[NACMD_MSG]);

    static  int     iIndex = 0;
            JE*     pJE;
            char*   pVal;

    if ( bFirst == TRUE ) {
        iIndex = JSON_FindPos( pJS, 0, "group");
    }

    while ( iIndex < pJS->nJE ) {
        pJE = &(pJS->xJE[iIndex]);
        iIndex++;

        if ( !strncmp(pJE->pKey, "_id", 3) ) {
            pJE->pVal[pJE->iVal ] = 0;
            return ( pJE->pVal );
        }
    }

    return (NULL);
}


// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_CheckVersion()
{
    JSET*   pJS = &(pJA->xJS[NACMD_MSG]);
    char*   pVersion;

    pVersion = JSON_FindVal(pJS, 0, "fw_version");

    if ( strcmp(pVersion, NIO_GetVersion()) <= 0 )      return (TRUE);


    {
        char    sSystem[1024];

        sprintf(sSystem, "./Install.sh %s", pVersion);

        system(sSystem);

        exit(0);
    }

    return (TRUE);
}


#define LTE_DEVICE      "/sys/class/net/usb0"
// -------------------------------------------------------------------
//    Interface Function
// -------------------------------------------------------------------
int     SP_GetNetworkType()
{
    struct  stat    xStat;

    int     iType   = (stat(LTE_DEVICE, &xStat) == 0) ? NETWORK_LTE : NETWORK_WIFI;

    return (iType);
}
