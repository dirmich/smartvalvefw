/*********************************************************************
    uNATS.cpp  (Rev 0.10)

    UI Interface Library

    Programmed by Stellar Respree

    Copyright(C) MemoryLab Ltd.
*********************************************************************/

#include "global.h"
#include "local.h"
#include "sw_type.h"
#include "nats.h"
#include "payload.h"


//--------------------------------------------------------------------
//  Global Configuration
//--------------------------------------------------------------------
#define NATS_CONF_VERBOSE       FALSE
#define NATS_CONF_PEDANTIC      FALSE
#define NATS_CONF_TLSREQUIRED   FALSE
#define NATS_CLIENT_LANG        "C"
#define NATS_CLIENT_VERSION     "3.6.0"
#define NATS_CLIENT_VERSION_B   "3.7.0-beta"


//--------------------------------------------------------------------
//  Global Definition
//--------------------------------------------------------------------
#define PAYLOAD_SIZE            4096


//--------------------------------------------------------------------
//  Data Structure
//--------------------------------------------------------------------
typedef struct {
    char    sBuffer[PAYLOAD_SIZE];
    int     iRecv;
} NAINFO_RECV_BUF;


typedef struct {
    char    sBuffer[PAYLOAD_SIZE];
    int     iSend;
} NAINFO_SEND_BUF;


typedef struct {
    char    sINBOX[256];
    char    sGUID[256];
    char    sMacID[256];
    char    sClientName[256];
    int     iProto;

    int     bLogin;
    char    sCommand[256];
    char*   pPayload;
} NAINFO_CI;


typedef struct {
    char    sServerID[256];
    char    sServerName[256];
    char    sClientID[256];
    char    sVersion[256];
    char    sHeaders[256];

    int     iProto;
} NAINFO_SI;


typedef struct {
    NAINFO_RECV_BUF     RB;
    NAINFO_SEND_BUF     SB;

    NAINFO_CI           C;
    NAINFO_SI           S;
} NAINFO;


static  NAINFO  xNI;
static  NAINFO* pNI = &xNI;

static  int     h;
static  int     iWait   = 2;

static  int     hNLog;


//--------------------------------------------------------------------
//  Internal Function
//--------------------------------------------------------------------
int     nats_Decode(char* pBuffer, int iBuffer, char** rpCommand, char** rpAction, char** rpData);
char*   nats_DecodeTag(const char* pTag, char* pStr, int*  piInt);
char*   nats_GetTail(const char* pTag, char* pStr, int*  piInt);
int     nats_Encode(char* pBuffer, int iBuffer, int iCommand);


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Init(void* pMM, int hLog)
{
    SP_Init((SWBOX*)pMM, hLog);

    srand(time(0));

/// sprintf(pNI->C.sINBOX, "K4LBO4RIMVAXTTHV0CCMVX");
    for ( int i =  0 ; i < 20 ; i++ ) {
        pNI->C.sINBOX[i] = 'A' + rand() % 26;
    }
    pNI->C.sINBOX[20] = 0;

/// strcpy(pNI->C.sMacID,       "e4:5f:01:3b:7d:23");
/// strcpy(pNI->C.sClientName,  "Samdori Board");
    strcpy(pNI->C.sMacID,       ((SWBOX*)pMM)->xCI.sControllerMacID);
    strcpy(pNI->C.sClientName,  ((SWBOX*)pMM)->xCI.sModelName);

    hNLog = hLog;
    LogConcatn(hNLog, "\n\n");
    LogPrintfn(hNLog, "========================================\n");
    LogPrintfn(hNLog, "  NATS Logging Started\n");
    LogPrintfn(hNLog, "========================================\n");

    return (TRUE);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Connect(char* pServerAddr, int iPort)
{
    char*   pAddr;

    strtok(pServerAddr, ":/\r\n");

    pAddr   = strtok(NULL, ":/\r\n");
    iPort   = atoi( strtok(NULL, ":/\r\n") );

#ifdef ARDUINO_ESP32
    SockConnect(pAddr, iPort);
#else
    SockInit();

    h   = TCP_Connect(GetHostIP(pAddr), iPort);
#endif

    return (TRUE);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Disconnect()
{
#ifdef ARDUINO_ESP32
/// SockClose(h);
#else
    SockClose(h);
#endif

    return (TRUE);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_ReadInfo()
{
    pNI->RB.iRecv = SockRead(h, pNI->RB.sBuffer, PAYLOAD_SIZE, iWait, '\n');
    usleep(100 * 1000);         // Sleep for SockRead 0 time delay

    LogConcatn(hNLog, "\n");
    LogPrintfn(hNLog, "[R]:%s\n\n", pNI->RB.sBuffer);

    nats_Decode(pNI->RB.sBuffer, pNI->RB.iRecv, NULL, NULL, NULL);      // Info

    return (TRUE);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Read()
{
    char*   pLoad = pNI->RB.sBuffer;

    int     iNACMD;

    pNI->RB.iRecv = SockRead(h, pNI->RB.sBuffer, PAYLOAD_SIZE, iWait, '\n');
    usleep(100 * 1000);         // Sleep for SockRead 0 time delay

    if ( pNI->RB.iRecv > 0) {
        if ( !strncmp(pLoad, "MSG", 3) ) {      // Add Payload
            pLoad += pNI->RB.iRecv;
            pNI->RB.iRecv += SockRead(h, pLoad, PAYLOAD_SIZE, iWait, '\n');
        }
    }

    {
        static  int     iLastRecv = 0;

        if ( (iLastRecv <= 0) && (pNI->RB.iRecv <= 0) ) {
            LogConcatn(hNLog, ".");
        }
        else {
            LogConcatn(hNLog, "\n");
            LogPrintfn(hNLog, "[R]:%s\n", pNI->RB.sBuffer);
        }

        iLastRecv = pNI->RB.iRecv;
    }

    if ( pNI->RB.iRecv > 0 ) {
        iNACMD = nats_Decode(pNI->RB.sBuffer, pNI->RB.iRecv, NULL, NULL, NULL);
    }
    else {
        iNACMD = 0;
    }

    return (iNACMD);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Send(int iNACMD)
{
    pNI->SB.iSend = nats_Encode(pNI->SB.sBuffer, PAYLOAD_SIZE, iNACMD);

    SockWrite(h, pNI->SB.sBuffer, pNI->SB.iSend, 10);

    LogConcatn(hNLog, "\n");
    LogPrintfn(hNLog, "[W]:%s\n", pNI->SB.sBuffer);

    return (TRUE);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     nats_Decode(char* pBuffer, int iBuffer, char** rpCommand, char** rpAction, char** rpData)
{
    int     iCommand    = 0;

    char*   pCommand    = NULL;
    char*   pAction     = NULL;
    char*   pData       = NULL;

    if ( !strncmp(pBuffer, "PING", 4) )         iCommand = NACMD_PING;
    if ( !strncmp(pBuffer, "PONG", 4) )         iCommand = NACMD_PONG;

    if ( !strncmp(pBuffer, "+OK", 3) )          iCommand = NACMD_OK;
    if ( !strncmp(pBuffer, "INFO", 4) )         iCommand = NACMD_INFO;
/// if ( !strncmp(pBuffer, "CONNECT", 7) )      iCommand = NACMD_CONNECT;
/// if ( !strncmp(pBuffer, "SUB", 3) )          iCommand = NACMD_SUB;
/// if ( !strncmp(pBuffer, "PUB", 3) )          iCommand = NACMD_PUB;
    if ( !strncmp(pBuffer, "MSG", 3) )          iCommand = NACMD_MSG;


    switch (iCommand) {
    case NACMD_PING:    break;
    case NACMD_PONG:    break;

    case NACMD_OK:      break;

    case NACMD_INFO:    nats_DecodeTag("server_id",     pNI->S.sServerID,   NULL);
                        nats_DecodeTag("server_name",   pNI->S.sServerName, NULL);
                        nats_DecodeTag("client_id",     pNI->S.sClientID,   NULL);
                        nats_DecodeTag("version",       pNI->S.sVersion,    NULL);
                        nats_DecodeTag("headers",       pNI->S.sHeaders,    NULL);
                        nats_DecodeTag("proto",         NULL,               &(pNI->S.iProto));
                        break;

    case NACMD_MSG:     if ( pNI->C.bLogin == FALSE ) {
                            nats_DecodeTag("_id",           pNI->C.sGUID,       NULL);

                            pCommand    = strstr(pNI->RB.sBuffer,  "_INBOX.");
                            pData       = strchr(pNI->RB.sBuffer, '\n') + 1;

                            pNI->C.bLogin = TRUE;
                        }
                        else {
                            nats_GetTail("ctrl.",       pNI->C.sCommand,    NULL);
                            pNI->C.pPayload = strchr(pNI->RB.sBuffer, '\n') + 1;

                            pCommand    = strstr(pNI->RB.sBuffer, "ctrl.");
                            pData       = strchr(pNI->RB.sBuffer, '\n') + 1;

                            if ( pCommand != NULL ) {
                                pAction   = strchr(pCommand + 5, '.') + 1;
                            }
                        }

                        if ( pAction != NULL ) {
                            if ( !strncmp(pAction, "add_group", 9) ) {
                                iCommand = NACMD_MSG_ADDGROUP;

                                strcpy(pNI->C.sGUID, strchr(pAction, '.') + 1);
                                strchr(pNI->C.sGUID, ' ')[0] = 0;
                            }
                            if ( !strncmp(pAction, "rm_group", 8) ) {
                                iCommand = NACMD_MSG_DELGROUP;

                                strcpy(pNI->C.sGUID, strchr(pAction, '.') + 1);
                                strchr(pNI->C.sGUID, ' ')[0] = 0;
                            }
                        }

                        if ( iCommand == NACMD_MSG ) {
                        /// ========================================
                            SP_Decode(iCommand, pCommand, pData);       // Decode Detail Complex
                        /// ========================================
                        }

                        break;

    default:            break;
    }

    if ( rpCommand != NULL )     *rpCommand = pCommand;
    if ( rpAction  != NULL )     *rpAction  = pAction;
    if ( rpData    != NULL )     *rpData    = pData;

    return (iCommand);
}


//--------------------------------------------------------------------
//  Private Function
//--------------------------------------------------------------------
char*   nats_DecodeTag(const char* pTag, char* pStr, int* piInt)
{
    char*   pSeek;
    char*   pLast;
    char    sStr[128];

    pSeek = pNI->RB.sBuffer;

    pSeek = strstr(pSeek, pTag);
    if ( pSeek == NULL )        return (FALSE);

    pSeek = pSeek + strlen(pTag) + 1 + 1;       // add " and :

    pSeek = (pSeek[0] == '\"') ? pSeek + 1 : pSeek;

    pLast = strchr(pSeek, ',');
    if ( pLast == NULL )        pLast = pNI->RB.sBuffer + pNI->RB.iRecv;
    pLast = (pLast[-1] == '"') ? pLast - 1 : pLast - 0;

    if ( pStr != NULL ) {
        strncpy(pStr, pSeek, pLast - pSeek);
        pStr[pLast - pSeek] = 0;
    }
    else {
        strncpy(sStr, pSeek, pLast - pSeek);
        sStr[pLast - pSeek] = 0;
        *piInt = atoi(sStr);
    }

    return (pSeek);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
char*   nats_GetTail(const char* pTag, char* pStr, int*  piInt)
{
    char    sTag[128];
    char*   pSeek;
    char*   pLast;
    char    sStr[128];

    strcpy(sTag, pTag);
    if ( sTag[strlen(sTag) - 1] == '*' )        sTag[strlen(sTag) - 1] = 0;

    pSeek = pNI->RB.sBuffer;

    pSeek = strstr(pSeek, sTag);
    if ( pSeek == NULL )        return (FALSE);

    pSeek = pSeek + strlen(sTag);
    pSeek = strchr(pSeek, '.');

    if ( pSeek == NULL )        return (FALSE);

    pSeek = pSeek + 1;
    pLast = strchr(pSeek, ' ');

    if ( pStr != NULL ) {
        strncpy(pStr, pSeek, pLast - pSeek);
        pStr[pLast - pSeek] = 0;
    }
    else {
        strncpy(sStr, pSeek, pLast - pSeek);
        sStr[pLast - pSeek] = 0;
        *piInt = atoi(sStr);
    }

    return (pSeek);
}


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     nats_Encode(char* pBuffer, int iBuffer, int iCommand)
{
/// char    sCommand[128];
/// char    sPayload[PAYLOAD_SIZE];
    char    sName[128];

    char*   pEncode;
    int     bFirst = TRUE;
    char*   pGroup;
    char*   pAppend;

    switch (iCommand) {
    case NACMD_PING:    sprintf(pBuffer, "PING" "\r\n");
                        break;

    case NACMD_PONG:    sprintf(pBuffer, "PONG" "\r\n");
                        break;

    case NACMD_INFO:    break;

    case NACMD_CONNECT: sprintf(pBuffer,
                        "CONNECT {"
                            "'verbose':%s,"
                            "'pedantic':%s,"
                            "'tls_required':%s,"
                            "'name':'',"
                            "'lang':'%s',"
                            "'version\":'%s',"

                            "'protocol\':1,"
                            "'echo\":true,"
                            "'headers\":true,"
                            "'no_responders\":true"
                        "}"
                        "\r\n",
                    /// "\r\nPING",
                        NATS_CONF_VERBOSE ? "true" : "false",
                        NATS_CONF_PEDANTIC ? "true" : "false",
                        NATS_CONF_TLSREQUIRED ? "true" : "false",
                        NATS_CLIENT_LANG,
                        NATS_CLIENT_VERSION_B);
                        break;

    case NACMD_SUB:     if ( pNI->C.bLogin == FALSE ) {
                            sprintf(pBuffer,
                            "SUB _INBOX.%s.* %d" "\r\n",
                            pNI->C.sINBOX, 1);
                            break;
                        }

                        /// Subscribe User
                        {
                            sprintf(pBuffer,
                            "SUB ctrl.%s.> %d" "\r\n",
                            pNI->C.sGUID, 2);
                        }

                        /// Subscribe Group
                        while ( TRUE ) {
                            pGroup = SP_GetGroup(bFirst);
                            if ( pGroup == NULL )       break;

                            bFirst = FALSE;

                            pAppend = pBuffer + strlen(pBuffer);
                            sprintf(pAppend,
                            "SUB ctrl.%s.> %d" "\r\n",
                            pGroup, 2);
                        }

                        break;

    case NACMD_MSG_ADDGROUP:
                        sprintf(pBuffer,
                        "SUB ctrl.%s.> %d" "\r\n",
                        pNI->C.sGUID, 2);
                        break;

    case NACMD_MSG_DELGROUP:
                        sprintf(pBuffer,
                        "UNSUB ctrl.%s.> %d" "\r\n",
                        pNI->C.sGUID, 2);
                        break;

    case NACMD_PUB_LOGIN:
                        sprintf(sName, "{'name':'%s'}",
                        pNI->C.sClientName);

                        sprintf(pBuffer,
                        "PUB server.login.%s _INBOX.%s.0 %d\r\n%s" "\r\n",
                        pNI->C.sMacID,
                        pNI->C.sINBOX,
                        strlen(sName),
                        sName);
                        break;

    case NACMD_PUB_STATUS:
    case NACMD_PUB_MONITOR:
    case NACMD_PUB_ALARM:
                        sprintf(pBuffer, "PUB ");
                        pEncode = pBuffer + strlen(pBuffer);

                    /// ========================================
                    /// SP_Encode(iCommand, sCommand, sPayload);        // Encode Detail Complex
                    /// sprintf(pBuffer, "PUB %s %d\r\n%s" "\r\n", sCommand, 1234, spayload);
                    /// ========================================

                    /// ========================================
                        SP_Encode(iCommand, pEncode, NULL);             // Encode Detail Complex
                    /// ========================================

                        break;

    default:            break;
    }

    pNI->SB.iSend = strlen(pBuffer);

    for ( int i = 0 ; i < pNI->SB.iSend ; i++ ) {
        if ( pBuffer[i] == '\'' )   pBuffer[i] = '"';
    }

    return (pNI->SB.iSend);
}
