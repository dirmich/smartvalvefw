import sys
import os
import requests
import threading

def setInterval(func):
    sec = int(sys.argv[3])
#    if "UPLOAD_INTERVAL" in os.environ:
#        esec = int(os.environ["UPLOAD_INTERVAL"])
#        if (esec > 0):
#            sec = esec

    def wrapper():
        func()
        setInterval(func)
#   print("interval = " , sec)
    t = threading.Timer(sec, wrapper)
    t.start()
    return t

def uploadSample():
#   url = 'https://remote.komoto.co.kr:3000/api/image/upload'
    url = sys.argv[1]
    user_id = sys.argv[2]
    filename = 'capture.jpg'
    upload(url,user_id, filename)

def upload(url,id,filename):
##  ret = os.system("fswebcam    -r 800*600 {}".format(filename))
    ret = os.system("fswebcam -q -r 800*600 {}".format(filename))
##  print("Ret = {}".format(ret))

    if ret == 0:
##      print("Uploading..")
        file = open(filename,'rb')
        files = { 'image':file, }
        param = {'id':id}
        res = requests.post(url, files=files, data=param)
##      print("Ret = {}".format(res));


pid = os.getpid()
f = open('./quit_camera','w')
f.write('kill ' + str(pid))
f.close()
os.chmod('./quit_camera', 0o777)

setInterval(uploadSample)
