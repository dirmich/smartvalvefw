sleep 5

if [-c "/dev/ttyUSB0"] ; then
    sudo ifconfig wlan0 down
    echo running LTE mode
    sleep 90
else
    echo running WIFI mode
    sleep 15
fi


bluetoothctl pairable off
bluetoothctl power on
bluetoothctl discoverable on

./v &
sleep 3
python ./ble/ble.py &
