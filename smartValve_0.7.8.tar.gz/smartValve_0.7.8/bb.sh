echo "raspberry" | sudo -S reboot
