sleep 5

if [ -c "/dev/ttyUSB0" ] ; then
    echo running LTE mode
    sudo ifconfig wlan0 down
    sleep 90
else
    echo running WIFI mode
    sudo ifconfig wlan0 up
    sleep 15
fi


bluetoothctl pairable off
bluetoothctl power on
bluetoothctl discoverable on

./v &
sleep 3
python ./ble/ble.py &
