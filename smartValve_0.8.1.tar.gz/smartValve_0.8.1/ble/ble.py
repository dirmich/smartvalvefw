###############################
# BluezHandler example
#
# David, Shin @ Highmaru, Inc
###############################
from BluezHandler import Characteristic, Descriptor,BluezHandler
from gi.repository import GLib
import json
import os.path
import dbus
# import BluezHandler

FIFO_BLE_RD = '/tmp/FIFO_SIO_BLE'
FIFO_BLE_WR = '/tmp/FIFO_BLE_SIO'
ENVFILE = '/home/pi/smartValve/ble/getenv.txt'
STATFILE = '/home/pi/smartValve/ble/getstat.txt'

SMARTVALVE_SERVICE_UUID =   '0000FFE0-0000-1000-8000-00805F9B34FB'
SMARTVALVE_CONTROL_UUID =   '0000FFE1-0000-1000-8000-00805F9B34FB'
SMARTVALVE_SENSOR_UUID =    '0000FFE2-0000-1000-8000-00805F9B34FB'
SMARTVALVE_ENV_UUID =       '0000FFE3-0000-1000-8000-00805F9B34FB'
LOCAL_NAME =                   'SmartValve'

mainloop = None
lastrc= None
def read_nonblocking(path, bufferSize=1024, timeout=.100):
    import time
    """
    implementation of a non-blocking read
    works with a named pipe or file
    errno 11 occurs if pipe is still written too, wait until some data
    is available
    """
    grace = True
    result = None
    try:
        pipe = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        while True:
            try:
                buf = os.read(pipe, bufferSize)
                if not buf:
                    break
                else:
                    content = buf.decode("utf-8")
                    # line = content.split("\n")
                    # result.extend(line)
                    result = buf
            except OSError as e:
                if e.errno == 11 and grace:
                    # grace period, first write to pipe might take some time
                    # further reads after opening the file are then successful
                    time.sleep(timeout)
                    grace = False
                else:
                    break

    except OSError as e:
        if e.errno == errno.ENOENT:
            pipe = None
        else:
            raise e

    return result

class EnvCharacteristic(Characteristic):
    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, SMARTVALVE_ENV_UUID,
                                ['read','write'], service)
        self.value=[]
        self.add_descriptor(EnvDescriptor(bus,0,self))

    def WriteValue(self, value, options):
        print('W0] '+str(value))

        try:
            strIn = ''.join([str(v) for v in value])
            strIn = '[WE]' + strIn
            print(strIn)

            fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
            os.write(fifow, bytes(strIn, 'utf-8'))
            os.close(fifow)

            #print('W2] '+strIn)

        except:
            print("WEerr]: %s" % [int(v) for v in value])
        self.value = value

    def ReadValue(self, options):
        try:
            strIn = '[RE]'
            fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
            os.write(fifow, bytes(strIn, 'utf-8'))
            os.close(fifow)
            # print('ACK ')
            # print('ACK2 ')
            # fifor = os.open(FIFO_BLE_RD, os.O_RDONLY | os.O_NONBLOCK)
            fifor = os.open(ENVFILE, os.O_RDONLY | os.O_NONBLOCK)
            # print('ACK3 ')
            # rd = os.read(fifor, bytes(strIn, 'utf-8'))
            rd = os.read(fifor,1024)
            print('ACK '+rd.decode('utf-8'))
            os.close(fifor)
            # print('W2] '+strIn)
            return rd

    ##//    print('R] '+repr(self.value))
    ##//    return self.value
            # print('[RE] {}'.format(options))
        except:
            print("REerr]: %s" % [int(v) for v in value])

        return [
                 dbus.Byte('T'), dbus.Byte('e'), dbus.Byte('s'), dbus.Byte('t')
        ]

class ControlCharacteristic(Characteristic):
    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, SMARTVALVE_CONTROL_UUID,
                                ['read','write'], service)
        self.value=[]
        self.add_descriptor(EnvDescriptor(bus,1,self))

    def WriteValue(self, value, options):
        print('WC] '+str(value))

        try:
            strIn = ''.join([str(v) for v in value])
            strIn = '[WC]' + strIn
            print(strIn)

            fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
            os.write(fifow, bytes(strIn, 'utf-8'))
            os.close(fifow)

            #print('W2] '+strIn)

        except:
            print("WCerr]: %s" % [int(v) for v in value])
        self.value = value

class EnvDescriptor(Descriptor):
    """
    Dummy test descriptor. Returns a static value.

    """
    TEST_DESC_UUID = '12345678-1234-5678-1234-56789abcdef2'

    def __init__(self, bus, index, characteristic):
        Descriptor.__init__(
                self, bus, index,
                self.TEST_DESC_UUID,
                ['read', 'write'],
                characteristic)

    def ReadValue(self, options):
        print('RD]')
        return [
                dbus.Byte('T'), dbus.Byte('e'), dbus.Byte('s'), dbus.Byte('t')
        ]
    def WriteValue(self, value, options):
    #   print('WD] '+str(value))

        try:
            strIn = ''.join([str(v) for v in value])
            strIn = '[WD]' + strIn
            print(strIn)

            fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
            os.write(fifow, bytes(strIn, 'utf-8'))
            os.close(fifow)

            #print('W2] '+strIn)

        except:
            print("WCerr]: %s" % [int(v) for v in value])
        self.value = value

class SensorCharacteristic(Characteristic):
    def __init__(self, bus, index, service):
        Characteristic.__init__(self, bus, index, SMARTVALVE_SENSOR_UUID,
                                ['read'], service)
        self.value=[]
        self.add_descriptor(EnvDescriptor(bus,1,self))

    def ReadValue(self, options):
        try:
            strIn = '[RC]'
            # test = [
            #             dbus.Byte('T'), dbus.Byte('e'), dbus.Byte('s'), dbus.Byte('t')
            #         ]
            print('1')
            test = dbus.String('Test')
            print('2')
            fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
            os.write(fifow, bytes(strIn, 'utf-8'))
            os.close(fifow)
            # fifor = os.open(FIFO_BLE_RD, os.O_RDONLY | os.O_NONBLOCK)
            # # rd = os.read(fifor, bytes(strIn, 'utf-8'))
            # rd = os.read(fifor,1024)
            print('3')
            # rd = read_nonblocking(FIFO_BLE_RD)
            fifor = os.open(STATFILE, os.O_RDONLY | os.O_NONBLOCK)
            # print('ACK3 ')
            # rd = os.read(fifor, bytes(strIn, 'utf-8'))
            rd = os.read(fifor,1024)
            print('ACK '+rd.decode('utf-8'))
            os.close(fifor)
            
            print('4')
            if (rd == None):                
                if (lastrc == None):
                    print('5')
                    print('ACK:None'+test)
                    return test
                else:
                    return lastrc
            else:
                print('3')
                print('ACK '+rd.decode('utf-8'))
                lastrc = rd
                print('4')
                
            # print('ACK4 '+rd.decode('utf-8'))
            # os.close(fifor)
            # print('W2] '+strIn)
                return rd

    ##//    print('R] '+repr(self.value))
    ##//    return self.value
            # print('[RE] {}'.format(options))
        except:
            print("RCerr]: ")


def main():

    mainloop = GLib.MainLoop()

#    fifow = os.open(FIFO_BLE_WR, os.O_RDWR | os.O_NONBLOCK)
#    os.write(fifow, bytes('hello', 'utf-8'))
#    os.close(fifow)

    man = BluezHandler()
    service = man.setApplication(LOCAL_NAME,SMARTVALVE_SERVICE_UUID)
    service.add_characteristic(EnvCharacteristic(man.bus,3,service))
    service.add_characteristic(ControlCharacteristic(man.bus,1,service))
    service.add_characteristic(SensorCharacteristic(man.bus,2,service))
    man.start()
    try:
        mainloop.run()
    except KeyboardInterrupt:
        man.Release()

if __name__ == '__main__':
    main()
