python CameraUpload.py https://remote.komoto.co.kr:3000/api/image/upload 67283a543afc331e1a4c33a0 20
