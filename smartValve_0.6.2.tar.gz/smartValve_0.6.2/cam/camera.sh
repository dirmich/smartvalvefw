#Reference script only:
python CameraUpload.py https://remote.komoto.co.kr:3000/api/image/upload 65602c95477ae9b94ab097e1 20 4053
