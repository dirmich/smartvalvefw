python CameraUpload.py https://remote.komoto.co.kr:3000/api/image/upload 66f3bb9d3afc331e1a4b788b 30
