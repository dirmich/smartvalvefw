cd ..
sudo rm smartValve_$1.tar.gz
sleep 1
wget https://raw.githubusercontent.com/dirmich/smartvalvefw/main/smartValve_$1.tar.gz
tar -xf smartValve_$1.tar.gz
sudo rm -f smartValve
sudo ln -s smartValve_$1 smartValve
sudo reboot now
